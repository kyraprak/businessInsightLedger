package com.ledger.ui;

import com.ledger.model.Transaction;
import com.ledger.service.LedgerService;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Scanner;

public class ConsoleUI {

    private final LedgerService service;
    private final Scanner scanner = new Scanner(System.in);

    public ConsoleUI(LedgerService service) {
        this.service = service;
    }

    public void start() {
        while (true) {
            System.out.println("\n=== BUSINESS LEDGER ===");
            System.out.println("D) Add Deposit");
            System.out.println("P) Make Payment");
            System.out.println("L) Ledger");
            System.out.println("X) Exit");

            String input = scanner.nextLine().toUpperCase();

            switch (input) {
                case "D" -> addTransaction(true);
                case "P" -> addTransaction(false);
                case "L" -> showLedger();
                case "X" -> System.exit(0);
            }
        }
    }

    private void addTransaction(boolean isDeposit) {
        System.out.print("Description: ");
        String desc = scanner.nextLine();

        System.out.print("Vendor: ");
        String vendor = scanner.nextLine();

        System.out.print("Amount: ");
        double amount = Double.parseDouble(scanner.nextLine());

        if (!isDeposit) amount *= -1;

        System.out.print("Category: ");
        String category = scanner.nextLine();

        System.out.print("Mood (optional): ");
        String mood = scanner.nextLine();

        System.out.print("Context (optional): ");
        String context = scanner.nextLine();

        Transaction t = new Transaction(
                LocalDate.now(),
                LocalTime.now(),
                desc,
                vendor,
                amount,
                category,
                mood,
                context
        );

        service.add(t);
    }

    private void showLedger() {
        List<Transaction> transactions = service.getAll();

        transactions.forEach(t ->
                System.out.printf("%s | %s | %s | %s | %.2f%n",
                        t.getDate(),
                        t.getTime(),
                        t.getDescription(),
                        t.getVendor(),
                        t.getAmount())
        );
    }
}