package com.ledger.model;

// Enum representing the type of transaction.

// Helps standardize transaction classification instead of relying on raw values.

public enum TransactionType {
    DEPOSIT,
    PAYMENT
}
