package com.ledger.model;

import java.time.LocalDate;
import java.time.LocalTime;

public class Transaction {
    private final LocalDate date;
    private final LocalTime time;
    private final String description;
    private final String vendor;
    private final double amount;
    private final String category;
    private final String mood;
    private final String context;

    // Represents a single financial transaction.
    // This model is constant once created and contains all metadata.
    // related to a transaction including optional behavioral fields.

    public Transaction(LocalDate date, LocalTime time, String description,
                       String vendor, double amount,
                       String category, String mood, String context) {
        this.date = date;
        this.time = time;
        this.description = description;
        this.vendor = vendor;
        this.amount = amount;
        // Enhanced fields - bonus features
        this.category = category;
        this.mood = mood;
        this.context = context;
    }

    // Determines if transaction is a deposit.
    public boolean isDeposit() {
        return amount > 0;
    }
    // Determines if transaction is a payment.
    public boolean isPayment() {
        return amount < 0;
    }

    // Converts transaction into pipe-delimited CSV format.
    // Handles optional fields safely.
    public String toCsv() {
        return String.join("|",
                date.toString(),
                time.toString(),
                description,
                vendor,
                String.valueOf(amount),
                category == null ? "" : category,
                mood == null ? "" : mood,
                context == null ? "" : context
        );
    }
    // Getters-> method used to "get" the value of an object's internal property.
    public LocalDate getDate() { return date; }
    public LocalTime getTime() { return time; }
    public String getDescription() { return description; }
    public String getVendor() { return vendor; }
    public double getAmount() { return amount; }
}

// optional future use, saved
// public String getCategory() { return category; }
// public String getMood() { return mood; }
// public String getContext() { return context; }