package com.ledger.repository;

import com.ledger.model.Transaction;

import java.io.*;
import java.nio.file.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.*;

// Repository layer responsible for reading and writing
// transactions to a CSV file.

public class TransactionRepository {

    private final String fileName = "transactions.csv";

    //Reads all transactions from the CSV file.
    // @return list of transactions.


    public List<Transaction> findAll() {
        List<Transaction> transactions = new ArrayList<>();

        try {
            // If file doesn't exist, return empty list
            if (!Files.exists(Paths.get(fileName))) return transactions;

            List<String> lines = Files.readAllLines(Paths.get(fileName));

            for (String line : lines) {
                String[] parts = line.split("\\|");

                // Map CSV line -> Transaction object
                transactions.add(new Transaction(
                        LocalDate.parse(parts[0]),
                        LocalTime.parse(parts[1]),
                        parts[2],
                        parts[3],
                        Double.parseDouble(parts[4]),
                        parts.length > 5 ? parts[5] : "",
                        parts.length > 6 ? parts[6] : "",
                        parts.length > 7 ? parts[7] : ""
                ));
            }

        } catch (IOException e) {
            System.out.println("Error reading file.");
        }

        return transactions;
    }


    // Saves a single transaction to the CSV file.
    // Appends to file instead of overwriting.

    public void save(Transaction transaction) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName, true))) {
            writer.write(transaction.toCsv());
            writer.newLine();
        } catch (IOException e) {
            System.out.println("Error saving transaction.");
        }
    }
}