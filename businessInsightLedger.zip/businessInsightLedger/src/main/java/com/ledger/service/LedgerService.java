package com.ledger.service;

import com.ledger.model.Transaction;
import com.ledger.repository.TransactionRepository;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

// Service layer containing business logic for transaction handling.

// Responsible for:
// - Sorting
// - Filtering
// - Coordinating repository operations

public class LedgerService {

    private final TransactionRepository repo;

    public LedgerService(TransactionRepository repo) {
        this.repo = repo;
    }

    //  Retrieves all transactions sorted by newest first.
    public List<Transaction> getAll() {
        return repo.findAll()
                .stream()
                .sorted(Comparator.comparing(Transaction::getDate)
                        .thenComparing(Transaction::getTime)
                        .reversed())
                .collect(Collectors.toList());
    }

    // Adds a new transaction to the system.
    public void add(Transaction t) {
        repo.save(t);
    }
}