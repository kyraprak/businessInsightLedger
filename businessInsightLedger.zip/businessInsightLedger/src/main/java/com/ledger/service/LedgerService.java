package com.ledger.service;

import com.ledger.model.Transaction;
import com.ledger.repository.TransactionRepository;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class LedgerService {

    private final TransactionRepository repo;

    public LedgerService(TransactionRepository repo) {
        this.repo = repo;
    }

    public List<Transaction> getAll() {
        return repo.findAll()
                .stream()
                .sorted(Comparator.comparing(Transaction::getDate)
                        .thenComparing(Transaction::getTime)
                        .reversed())
                .collect(Collectors.toList());
    }

    public void add(Transaction t) {
        repo.save(t);
    }
}