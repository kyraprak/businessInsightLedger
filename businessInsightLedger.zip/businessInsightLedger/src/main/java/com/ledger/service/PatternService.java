package com.ledger.service;

import com.ledger.model.Transaction;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

// Service responsible for detecting spending patterns.
// This is a bonus feature that adds analytical insight:
// - Recurring vendors
// - Spending behavior trends

public class PatternService {

    // Finds recurring vendors based on transaction frequency.

    public Map<String, Long> findRecurringVendors(List<Transaction> transactions) {
        return transactions.stream()
                .collect(Collectors.groupingBy(
                        Transaction::getVendor,
                        Collectors.counting()
                ));
    }

    // Identifies high spending transactions (spike/outlier detection).

    public List<Transaction> findLargeTransactions(List<Transaction> transactions, double threshold) {
        return transactions.stream()
                .filter(t -> Math.abs(t.getAmount()) > threshold)
                .collect(Collectors.toList());
    }
}
