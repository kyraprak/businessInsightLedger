package com.ledger.service;

import com.ledger.model.Transaction;

import java.util.*;
import java.util.stream.Collectors;

public class PatternService {

    public List<Transaction> findSpikes(List<Transaction> transactions) {
        double avg = transactions.stream()
                .mapToDouble(Transaction::getAmount)
                .average().orElse(0);

        return transactions.stream()
                .filter(t -> Math.abs(t.getAmount()) > avg * 2)
                .collect(Collectors.toList());
    }

    public Map<String, Long> recurringVendors(List<Transaction> transactions) {
        return transactions.stream()
                .collect(Collectors.groupingBy(Transaction::getVendor, Collectors.counting()));
    }
}