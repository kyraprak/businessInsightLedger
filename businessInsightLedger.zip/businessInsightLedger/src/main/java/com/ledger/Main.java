package com.ledger;

import com.ledger.repository.TransactionRepository;
import com.ledger.service.LedgerService;
import com.ledger.ui.ConsoleUI;

public class Main {
    public static void main(String[] args) {
        TransactionRepository repo = new TransactionRepository();
        LedgerService service = new LedgerService(repo);
        ConsoleUI ui = new ConsoleUI(service);

        ui.start();
    }
}

