package com.ledger;

import com.ledger.repository.TransactionRepository;
import com.ledger.service.LedgerService;
import com.ledger.ui.ConsoleUI;

public class Main {
    public static void main(String[] args) {
        // Repository handles file I/O (CSV persistence)
        TransactionRepository repo = new TransactionRepository();

        // Service contains business logic and data processing
        LedgerService service = new LedgerService(repo);

        // UI handles all user interaction
        ConsoleUI ui = new ConsoleUI(service);

        // Start the application loop
        ui.start();
    }
}

